<?php

use PEAR2\Net\RouterOS;
use PEAR2\Net\RouterOS\Client;
use PEAR2\Net\RouterOS\Request;

register_menu("Data Usage Monitor", true, "mst_data_usage_ui", 'NETWORK', 'ion ion-stats-bars', "New", "success");

function mst_data_usage_formatBytes($bytes, $precision = 2)
{
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}

function mst_data_usage_ui()
{
    global $ui, $routes;
    _admin();
    $ui->assign('_title', 'Data Usage Monitor');
    $ui->assign('_system_menu', 'network');
    
    $admin = Admin::_info();
    $ui->assign('_admin', $admin);
    
    // Get router information
    $router = ORM::for_table('tbl_routers')->where('enabled', '1')->find_one();
    if (!$router) {
        r2(U . 'settings/router-edit', 'e', 'Please configure Mikrotik Router first');
    }

    try {
        $client = Mikrotik::getClient($router['ip_address'], $router['username'], $router['password']);

        // Get all online users
        $onlineUsers = $client->sendSync(new RouterOS\Request('/ip/hotspot/active/print'));
        $usageData = $client->sendSync(new RouterOS\Request('/ip/hotspot/host/print'));

        // Convert RouterOS response to array for processing
        $usageDataArray = [];
        foreach ($usageData as $usage) {
            $usageDataArray[] = [
                'mac-address' => $usage->getProperty('mac-address'),
                'bytes-in' => $usage->getProperty('bytes-in'),
                'bytes-out' => $usage->getProperty('bytes-out')
            ];
        }

        // Process users and their data usage
        $users = [];
        foreach ($onlineUsers as $user) {
            $mac = $user->getProperty('mac-address');
            // Find matching usage data
            $usage = null;
            foreach ($usageDataArray as $u) {
                if ($u['mac-address'] === $mac) {
                    $usage = $u;
                    break;
                }
            }
            
            $users[] = [
                'user' => $user->getProperty('user'),
                'mac_address' => $mac,
                'uptime' => $user->getProperty('uptime'),
                'bytes_in' => mst_data_usage_formatBytes($usage ? $usage['bytes-in'] : 0),
                'bytes_out' => mst_data_usage_formatBytes($usage ? $usage['bytes-out'] : 0),
                'ip_address' => $user->getProperty('address')
            ];
        }

        $ui->assign('users', $users);
        $ui->display('mst_data_usage.tpl');

    } catch (Exception $e) {
        r2(U . 'dashboard', 'e', $e->getMessage());
    }
}

function mst_data_usage_disconnect()
{
    global $routes;
    _admin();
    
    $mac_address = $routes['2'];
    if (empty($mac_address)) {
        r2(U . 'plugin/mst_data_usage_ui', 'e', 'Invalid MAC Address');
    }

    // Get router information
    $router = ORM::for_table('tbl_routers')->where('enabled', '1')->find_one();
    if (!$router) {
        r2(U . 'settings/router-edit', 'e', 'Please configure Mikrotik Router first');
    }

    try {
        $client = Mikrotik::getClient($router['ip_address'], $router['username'], $router['password']);

        // Find and remove the user
        $request = new RouterOS\Request('/ip/hotspot/active/print');
        $request->setQuery(RouterOS\Query::where('mac-address', $mac_address));
        $users = $client->sendSync($request);

        if ($users) {
            foreach ($users as $user) {
                $remove = new RouterOS\Request('/ip/hotspot/active/remove');
                $remove->setArgument('numbers', $user->getProperty('.id'));
                $client->sendSync($remove);
            }
            r2(U . 'plugin/mst_data_usage_ui', 's', 'User has been disconnected');
        } else {
            r2(U . 'plugin/mst_data_usage_ui', 'e', 'User not found');
        }

    } catch (Exception $e) {
        r2(U . 'plugin/mst_data_usage_ui', 'e', $e->getMessage());
    }
}
