<?php

/**
 * MST Data Usage Plugin
 * Fetch online users and their data usage from Mikrotik router
 */

Hook::register('admin_menu_network', function () {
    global $_L;
    return [
        [
            'name' => 'Online Users',
            'link' => U . 'plugin/mst_data_usage_online_users',
            'icon' => 'ion ion-stats-bars',
        ]
    ];
});

function mst_data_usage_online_users()
{
    global $ui, $config;
    
    $router = Router::_info();
    if (empty($router)) {
        r2(U . 'settings/router-edit', 'e', 'Please configure Mikrotik Router first');
    }

    try {
        $client = new RouterOS\Client([
            'host' => $router['ip_address'],
            'user' => $router['username'],
            'pass' => $router['password'],
            'port' => $router['port']
        ]);

        // Get all online users
        $query = new RouterOS\Query('/ip/hotspot/active/print');
        $onlineUsers = $client->query($query)->read();

        // Get user data usage
        $usageQuery = new RouterOS\Query('/ip/hotspot/host/print');
        $usageData = $client->query($usageQuery)->read();

        // Combine user data with usage
        $users = [];
        foreach ($onlineUsers as $user) {
            $usage = array_filter($usageData, function($item) use ($user) {
                return $item['mac-address'] === $user['mac-address'];
            });
            
            $usage = reset($usage);
            $users[] = [
                'user' => $user['user'],
                'mac_address' => $user['mac-address'],
                'uptime' => $user['uptime'],
                'bytes_in' => Format::formatBytes($usage['bytes-in'] ?? 0),
                'bytes_out' => Format::formatBytes($usage['bytes-out'] ?? 0),
                'ip_address' => $user['address']
            ];
        }

        $ui->assign('users', $users);
        $ui->display('mst_data_usage.tpl');

    } catch (Exception $e) {
        r2(U . 'dashboard', 'e', $e->getMessage());
    }
}
